<!DOCTYPE html>
<html>
<head>
    <title>PostTest 11</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>

</body>
</html><?php /**PATH D:\#KULIAH\#SEMS5\praktikum web\Pertemuan 11\PostTest11\resources\views/template.blade.php ENDPATH**/ ?>